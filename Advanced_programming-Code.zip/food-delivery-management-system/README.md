# Food Delivery Management System

## Project Overview

The Food Delivery Management System is a Java-based data-driven application developed using Spring Boot and MySQL.

The system provides RESTful APIs for managing customers, restaurants, food items, orders and deliveries.

## Technologies

- Java
- Spring Boot
- Spring Data JPA
- MySQL
- Maven
- REST API
- Jakarta Validation

## Main Features

- Customer management
- Restaurant management
- Food item management
- Order management
- Delivery management
- CRUD operations
- Input validation
- Exception handling
- MySQL database integration
- RESTful API

## Project Architecture

The application follows a layered architecture:

Controller
→ Service
→ Repository
→ MySQL Database

## API Endpoints

### Customers

GET /api/customers

GET /api/customers/{id}

POST /api/customers

PUT /api/customers/{id}

DELETE /api/customers/{id}

### Restaurants

GET /api/restaurants

GET /api/restaurants/{id}

POST /api/restaurants

PUT /api/restaurants/{id}

DELETE /api/restaurants/{id}

### Food Items

GET /api/food-items

GET /api/food-items/{id}

POST /api/food-items

PUT /api/food-items/{id}

DELETE /api/food-items/{id}

### Orders

GET /api/orders

GET /api/orders/{id}

POST /api/orders

PUT /api/orders/{id}/status

DELETE /api/orders/{id}

### Deliveries

GET /api/deliveries

GET /api/deliveries/{id}

POST /api/deliveries

PUT /api/deliveries/{id}/status

## Database

Database name:

food_delivery_db

## Running the Application

1. Create the MySQL database.
2. Configure the MySQL username and password in application.properties.
3. Build the project using Maven.
4. Run the Spring Boot application.
5. Test the REST API using Postman.

## Project Demonstration

GitHub Repository:

[Add GitHub URL]

Video Demonstration:

[Add Video URL]
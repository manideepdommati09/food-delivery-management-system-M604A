package com.fooddelivery.system.controller;

import com.fooddelivery.system.dto.FoodItemRequest;
import com.fooddelivery.system.entity.FoodItem;
import com.fooddelivery.system.service.FoodItemService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/food-items")
public class FoodItemController {

    private final FoodItemService foodItemService;

    public FoodItemController(FoodItemService foodItemService) {
        this.foodItemService = foodItemService;
    }

    @GetMapping
    public List<FoodItem> getAllFoodItems() {
        return foodItemService.getAllFoodItems();
    }

    @GetMapping("/{id}")
    public FoodItem getFoodItem(@PathVariable Long id) {
        return foodItemService.getFoodItemById(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public FoodItem createFoodItem(
            @Valid @RequestBody FoodItemRequest request) {

        return foodItemService.createFoodItem(request);
    }

    @PutMapping("/{id}")
    public FoodItem updateFoodItem(
            @PathVariable Long id,
            @Valid @RequestBody FoodItemRequest request) {

        return foodItemService.updateFoodItem(id, request);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteFoodItem(@PathVariable Long id) {
        foodItemService.deleteFoodItem(id);
    }
}
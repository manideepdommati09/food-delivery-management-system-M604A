package com.fooddelivery.system.entity;

public enum Role {

    ADMIN,
    CUSTOMER
}

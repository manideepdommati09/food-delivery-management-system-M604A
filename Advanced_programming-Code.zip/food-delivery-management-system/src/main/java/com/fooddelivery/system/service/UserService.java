package com.fooddelivery.system.service;

import com.fooddelivery.system.dto.CreateUserRequest;
import com.fooddelivery.system.dto.RegisterRequest;
import com.fooddelivery.system.entity.Customer;
import com.fooddelivery.system.entity.Role;
import com.fooddelivery.system.entity.User;
import com.fooddelivery.system.exception.ResourceNotFoundException;
import com.fooddelivery.system.repository.CustomerRepository;
import com.fooddelivery.system.repository.UserRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final CustomerRepository customerRepository;

    public UserService(
            UserRepository userRepository,
            CustomerRepository customerRepository) {

        this.userRepository = userRepository;
        this.customerRepository = customerRepository;
    }

    @PostConstruct
    public void seedAdmin() {
        if (!userRepository.existsByUsername("admin")) {
            User admin = new User("admin", "admin123", Role.ADMIN);
            userRepository.save(admin);
        }
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User login(String username, String password) {
        User user = userRepository.findByUsername(username)
                .orElse(null);

        if (user == null || !user.getPassword().equals(password)) {
            return null;
        }

        return user;
    }

    @Transactional
    public User register(RegisterRequest request) {
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new IllegalArgumentException(
                    "Username already exists: " + request.getUsername());
        }

        Customer customer = new Customer(
                request.getName(),
                request.getEmail(),
                request.getPhone(),
                request.getAddress()
        );

        customer = customerRepository.save(customer);

        User user = new User(
                request.getUsername(),
                request.getPassword(),
                Role.CUSTOMER
        );

        user.setCustomer(customer);

        return userRepository.save(user);
    }

    @Transactional
    public User createUser(CreateUserRequest request) {
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new IllegalArgumentException(
                    "Username already exists: " + request.getUsername());
        }

        User user = new User(
                request.getUsername(),
                request.getPassword(),
                request.getRole() != null ? request.getRole() : Role.CUSTOMER
        );

        // If customer details are provided, create linked customer
        if (request.getName() != null && !request.getName().isBlank()) {
            Customer customer = new Customer(
                    request.getName(),
                    request.getEmail() != null && !request.getEmail().isBlank() ? request.getEmail() : request.getUsername() + "@fooddelivery.com",
                    request.getPhone() != null && !request.getPhone().isBlank() ? request.getPhone() : "N/A",
                    request.getAddress() != null && !request.getAddress().isBlank() ? request.getAddress() : "Default Address"
            );
            customer = customerRepository.save(customer);
            user.setCustomer(customer);
        }

        return userRepository.save(user);
    }

    public User getUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    @Transactional
    public void deleteUser(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with ID: " + id));

        if ("admin".equalsIgnoreCase(user.getUsername())) {
            throw new IllegalArgumentException("Cannot delete default admin user");
        }

        userRepository.delete(user);
    }
}

package com.fooddelivery.system.service;

import com.fooddelivery.system.entity.Delivery;
import com.fooddelivery.system.entity.DeliveryStatus;
import com.fooddelivery.system.entity.Order;
import com.fooddelivery.system.exception.ResourceNotFoundException;
import com.fooddelivery.system.repository.DeliveryRepository;
import com.fooddelivery.system.repository.OrderRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class DeliveryService {

    private final DeliveryRepository deliveryRepository;
    private final OrderRepository orderRepository;

    public DeliveryService(
            DeliveryRepository deliveryRepository,
            OrderRepository orderRepository) {

        this.deliveryRepository = deliveryRepository;
        this.orderRepository = orderRepository;
    }

    public List<Delivery> getAllDeliveries() {
        return deliveryRepository.findAll();
    }

    public Delivery getDeliveryById(Long id) {

        return deliveryRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Delivery not found with ID: " + id));
    }

    public Delivery createDelivery(
            Long orderId,
            String deliveryPerson) {

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Order not found with ID: " + orderId));

        Delivery delivery = new Delivery();

        delivery.setOrder(order);
        delivery.setDeliveryPerson(deliveryPerson);
        delivery.setDeliveryStatus(DeliveryStatus.ASSIGNED);

        return deliveryRepository.save(delivery);
    }

    public Delivery updateDeliveryStatus(
            Long id,
            DeliveryStatus status) {

        Delivery delivery = getDeliveryById(id);

        delivery.setDeliveryStatus(status);

        if (status == DeliveryStatus.DELIVERED) {
            delivery.setDeliveryTime(LocalDateTime.now());
        } else {
            delivery.setDeliveryTime(null);
        }

        return deliveryRepository.save(delivery);
    }
}
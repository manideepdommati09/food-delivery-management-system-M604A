package com.fooddelivery.system.controller;

import com.fooddelivery.system.entity.Delivery;
import com.fooddelivery.system.entity.DeliveryStatus;
import com.fooddelivery.system.service.DeliveryService;
import jakarta.validation.constraints.NotBlank;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/deliveries")
public class DeliveryController {

    private final DeliveryService deliveryService;

    public DeliveryController(DeliveryService deliveryService) {
        this.deliveryService = deliveryService;
    }

    @GetMapping
    public List<Delivery> getAllDeliveries() {
        return deliveryService.getAllDeliveries();
    }

    @GetMapping("/{id}")
    public Delivery getDelivery(@PathVariable Long id) {
        return deliveryService.getDeliveryById(id);
    }

    @PostMapping
    public Delivery createDelivery(
            @RequestParam Long orderId,
            @RequestParam @NotBlank String deliveryPerson) {

        return deliveryService.createDelivery(
                orderId,
                deliveryPerson
        );
    }

    @PutMapping("/{id}/status")
    public Delivery updateStatus(
            @PathVariable Long id,
            @RequestParam DeliveryStatus status) {

        return deliveryService.updateDeliveryStatus(id, status);
    }
}
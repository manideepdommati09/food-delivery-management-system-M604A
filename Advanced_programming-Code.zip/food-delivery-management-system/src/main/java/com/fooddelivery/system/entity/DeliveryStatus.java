package com.fooddelivery.system.entity;

public enum DeliveryStatus {

    ASSIGNED,
    PICKED_UP,
    IN_TRANSIT,
    DELIVERED,
    FAILED
}
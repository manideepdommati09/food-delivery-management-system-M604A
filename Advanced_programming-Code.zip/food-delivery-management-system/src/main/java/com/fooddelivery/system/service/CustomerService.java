package com.fooddelivery.system.service;

import com.fooddelivery.system.dto.CustomerRequest;
import com.fooddelivery.system.entity.Customer;
import com.fooddelivery.system.exception.ResourceNotFoundException;
import com.fooddelivery.system.repository.CustomerRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    public Customer getCustomerById(Long id) {
        return customerRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Customer not found with ID: " + id));
    }

    public Customer createCustomer(CustomerRequest request) {

        Customer customer = new Customer(
                request.getName(),
                request.getEmail(),
                request.getPhone(),
                request.getAddress()
        );

        return customerRepository.save(customer);
    }

    public Customer updateCustomer(Long id, CustomerRequest request) {

        Customer customer = getCustomerById(id);

        customer.setName(request.getName());
        customer.setEmail(request.getEmail());
        customer.setPhone(request.getPhone());
        customer.setAddress(request.getAddress());

        return customerRepository.save(customer);
    }

    public void deleteCustomer(Long id) {

        Customer customer = getCustomerById(id);

        customerRepository.delete(customer);
    }
}
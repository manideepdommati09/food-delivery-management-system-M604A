package com.fooddelivery.system.service;

import com.fooddelivery.system.dto.RestaurantRequest;
import com.fooddelivery.system.entity.Restaurant;
import com.fooddelivery.system.exception.ResourceNotFoundException;
import com.fooddelivery.system.repository.RestaurantRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RestaurantService {

    private final RestaurantRepository restaurantRepository;

    public RestaurantService(RestaurantRepository restaurantRepository) {
        this.restaurantRepository = restaurantRepository;
    }

    public List<Restaurant> getAllRestaurants() {
        return restaurantRepository.findAll();
    }

    public Restaurant getRestaurantById(Long id) {
        return restaurantRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Restaurant not found with ID: " + id));
    }

    public Restaurant createRestaurant(RestaurantRequest request) {

        Restaurant restaurant = new Restaurant(
                request.getName(),
                request.getAddress(),
                request.getPhone(),
                request.getCuisineType()
        );

        return restaurantRepository.save(restaurant);
    }

    public Restaurant updateRestaurant(
            Long id,
            RestaurantRequest request) {

        Restaurant restaurant = getRestaurantById(id);

        restaurant.setName(request.getName());
        restaurant.setAddress(request.getAddress());
        restaurant.setPhone(request.getPhone());
        restaurant.setCuisineType(request.getCuisineType());

        return restaurantRepository.save(restaurant);
    }

    public void deleteRestaurant(Long id) {

        Restaurant restaurant = getRestaurantById(id);

        restaurantRepository.delete(restaurant);
    }
}
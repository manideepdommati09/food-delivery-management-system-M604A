package com.fooddelivery.system.controller;

import com.fooddelivery.system.dto.LoginRequest;
import com.fooddelivery.system.dto.RegisterRequest;
import com.fooddelivery.system.entity.User;
import com.fooddelivery.system.service.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(
            @Valid @RequestBody LoginRequest request,
            HttpSession session) {

        User user = userService.login(
                request.getUsername(),
                request.getPassword()
        );

        if (user == null) {

            Map<String, Object> error = new HashMap<>();
            error.put("message", "Invalid username or password");

            return new ResponseEntity<>(error, HttpStatus.UNAUTHORIZED);
        }

        session.setAttribute("userId", user.getId());
        session.setAttribute("role", user.getRole().name());

        if (user.getCustomer() != null) {
            session.setAttribute("customerId", user.getCustomer().getId());
        }

        Map<String, Object> response = new HashMap<>();
        response.put("id", user.getId());
        response.put("username", user.getUsername());
        response.put("role", user.getRole().name());

        if (user.getCustomer() != null) {
            response.put("customerId", user.getCustomer().getId());
            response.put("customerName", user.getCustomer().getName());
        }

        return ResponseEntity.ok(response);
    }

    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> register(
            @Valid @RequestBody RegisterRequest request) {

        try {

            User user = userService.register(request);

            Map<String, Object> response = new HashMap<>();
            response.put("message", "Registration successful");
            response.put("id", user.getId());
            response.put("username", user.getUsername());

            return new ResponseEntity<>(response, HttpStatus.CREATED);

        } catch (IllegalArgumentException e) {

            Map<String, Object> error = new HashMap<>();
            error.put("message", e.getMessage());

            return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<Map<String, Object>> logout(HttpSession session) {

        session.invalidate();

        Map<String, Object> response = new HashMap<>();
        response.put("message", "Logged out successfully");

        return ResponseEntity.ok(response);
    }

    @GetMapping("/me")
    public ResponseEntity<Map<String, Object>> currentUser(HttpSession session) {

        Long userId = (Long) session.getAttribute("userId");

        if (userId == null) {

            Map<String, Object> error = new HashMap<>();
            error.put("message", "Not authenticated");

            return new ResponseEntity<>(error, HttpStatus.UNAUTHORIZED);
        }

        User user = userService.getUserById(userId);

        if (user == null) {

            Map<String, Object> error = new HashMap<>();
            error.put("message", "User not found");

            return new ResponseEntity<>(error, HttpStatus.UNAUTHORIZED);
        }

        Map<String, Object> response = new HashMap<>();
        response.put("id", user.getId());
        response.put("username", user.getUsername());
        response.put("role", user.getRole().name());

        if (user.getCustomer() != null) {
            response.put("customerId", user.getCustomer().getId());
            response.put("customerName", user.getCustomer().getName());
        }

        return ResponseEntity.ok(response);
    }
}

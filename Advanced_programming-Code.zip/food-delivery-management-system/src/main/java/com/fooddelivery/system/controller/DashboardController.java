package com.fooddelivery.system.controller;

import com.fooddelivery.system.entity.Order;
import com.fooddelivery.system.repository.*;
import com.fooddelivery.system.service.OrderService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    private final CustomerRepository customerRepository;
    private final RestaurantRepository restaurantRepository;
    private final FoodItemRepository foodItemRepository;
    private final OrderRepository orderRepository;
    private final DeliveryRepository deliveryRepository;
    private final OrderService orderService;

    public DashboardController(
            CustomerRepository customerRepository,
            RestaurantRepository restaurantRepository,
            FoodItemRepository foodItemRepository,
            OrderRepository orderRepository,
            DeliveryRepository deliveryRepository,
            OrderService orderService) {

        this.customerRepository = customerRepository;
        this.restaurantRepository = restaurantRepository;
        this.foodItemRepository = foodItemRepository;
        this.orderRepository = orderRepository;
        this.deliveryRepository = deliveryRepository;
        this.orderService = orderService;
    }

    @GetMapping("/admin")
    public ResponseEntity<Map<String, Object>> adminDashboard(
            HttpSession session) {

        String role = (String) session.getAttribute("role");

        if (!"ADMIN".equals(role)) {
            Map<String, Object> error = new HashMap<>();
            error.put("message", "Access denied");
            return new ResponseEntity<>(error, HttpStatus.FORBIDDEN);
        }

        List<Order> allOrders = orderRepository.findAll();

        BigDecimal totalRevenue = allOrders.stream()
                .filter(o -> o.getTotalAmount() != null)
                .map(Order::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        long activeOrders = allOrders.stream()
                .filter(o -> o.getStatus() != null &&
                        !o.getStatus().name().equals("DELIVERED") &&
                        !o.getStatus().name().equals("CANCELLED"))
                .count();

        Map<String, Object> dashboard = new HashMap<>();
        dashboard.put("customerCount", customerRepository.count());
        dashboard.put("restaurantCount", restaurantRepository.count());
        dashboard.put("foodItemCount", foodItemRepository.count());
        dashboard.put("orderCount", orderRepository.count());
        dashboard.put("deliveryCount", deliveryRepository.count());
        dashboard.put("totalRevenue", totalRevenue);
        dashboard.put("activeOrders", activeOrders);

        return ResponseEntity.ok(dashboard);
    }

    @GetMapping("/customer")
    public ResponseEntity<Map<String, Object>> customerDashboard(
            HttpSession session) {

        Long customerId = (Long) session.getAttribute("customerId");

        if (customerId == null) {
            Map<String, Object> error = new HashMap<>();
            error.put("message", "Access denied");
            return new ResponseEntity<>(error, HttpStatus.FORBIDDEN);
        }

        List<Order> myOrders = orderService.getOrdersByCustomerId(customerId);

        BigDecimal totalSpent = myOrders.stream()
                .filter(o -> o.getTotalAmount() != null)
                .map(Order::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        long activeOrders = myOrders.stream()
                .filter(o -> o.getStatus() != null &&
                        !o.getStatus().name().equals("DELIVERED") &&
                        !o.getStatus().name().equals("CANCELLED"))
                .count();

        long deliveredOrders = myOrders.stream()
                .filter(o -> o.getStatus() != null &&
                        o.getStatus().name().equals("DELIVERED"))
                .count();

        Map<String, Object> dashboard = new HashMap<>();
        dashboard.put("totalOrders", myOrders.size());
        dashboard.put("activeOrders", activeOrders);
        dashboard.put("deliveredOrders", deliveredOrders);
        dashboard.put("totalSpent", totalSpent);

        return ResponseEntity.ok(dashboard);
    }
}

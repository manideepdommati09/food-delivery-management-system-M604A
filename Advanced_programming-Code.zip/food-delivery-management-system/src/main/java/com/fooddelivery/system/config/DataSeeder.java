package com.fooddelivery.system.config;

import com.fooddelivery.system.entity.Customer;
import com.fooddelivery.system.entity.FoodItem;
import com.fooddelivery.system.entity.Restaurant;
import com.fooddelivery.system.entity.Role;
import com.fooddelivery.system.entity.User;
import com.fooddelivery.system.repository.CustomerRepository;
import com.fooddelivery.system.repository.FoodItemRepository;
import com.fooddelivery.system.repository.RestaurantRepository;
import com.fooddelivery.system.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class DataSeeder implements CommandLineRunner {

    private final UserRepository userRepository;
    private final CustomerRepository customerRepository;
    private final RestaurantRepository restaurantRepository;
    private final FoodItemRepository foodItemRepository;

    public DataSeeder(
            UserRepository userRepository,
            CustomerRepository customerRepository,
            RestaurantRepository restaurantRepository,
            FoodItemRepository foodItemRepository) {
        this.userRepository = userRepository;
        this.customerRepository = customerRepository;
        this.restaurantRepository = restaurantRepository;
        this.foodItemRepository = foodItemRepository;
    }

    @Override
    public void run(String... args) {
        // Ensure Admin user
        if (!userRepository.existsByUsername("admin")) {
            User admin = new User("admin", "admin123", Role.ADMIN);
            userRepository.save(admin);
        }

        // Ensure Demo Customer user
        if (!userRepository.existsByUsername("customer")) {
            Customer demoCustomer = customerRepository.findByEmail("customer@example.com")
                    .orElseGet(() -> {
                        Customer c = new Customer(
                                "Alex Johnson",
                                "customer@example.com",
                                "+1 555-0142",
                                "742 Evergreen Terrace, Springfield"
                        );
                        return customerRepository.save(c);
                    });

            User customerUser = new User("customer", "customer123", Role.CUSTOMER);
            customerUser.setCustomer(demoCustomer);
            userRepository.save(customerUser);
        }

        // Seed sample restaurants and food items if empty
        if (restaurantRepository.count() == 0) {
            // Restaurant 1: Italian
            Restaurant r1 = new Restaurant(
                    "Bella Italia Bistro",
                    "124 Roma Blvd, Downtown",
                    "555-0101",
                    "Italian"
            );
            r1 = restaurantRepository.save(r1);

            FoodItem f1 = new FoodItem();
            f1.setName("Truffle Mushroom Pizza");
            f1.setDescription("Hand-tossed artisan crust, creamy mozzarella, black truffle oil and sautéed wild forest mushrooms");
            f1.setPrice(new BigDecimal("14.99"));
            f1.setAvailable(true);
            f1.setRestaurant(r1);
            foodItemRepository.save(f1);

            FoodItem f2 = new FoodItem();
            f2.setName("Classic Lasagna Bolognese");
            f2.setDescription("Layered silky pasta with rich slow-simmered beef ragù, creamy béchamel and aged parmesan");
            f2.setPrice(new BigDecimal("13.50"));
            f2.setAvailable(true);
            f2.setRestaurant(r1);
            foodItemRepository.save(f2);

            FoodItem f3 = new FoodItem();
            f3.setName("Tiramisu Tradizionale");
            f3.setDescription("Espresso-soaked Italian savoiardi with light mascarpone cream and Belgian cocoa powder");
            f3.setPrice(new BigDecimal("6.50"));
            f3.setAvailable(true);
            f3.setRestaurant(r1);
            foodItemRepository.save(f3);

            // Restaurant 2: Japanese
            Restaurant r2 = new Restaurant(
                    "Tokyo Ramen & Sushi Bar",
                    "88 Sakura Way, Midtown",
                    "555-0102",
                    "Japanese"
            );
            r2 = restaurantRepository.save(r2);

            FoodItem f4 = new FoodItem();
            f4.setName("Spicy Tonkotsu Ramen");
            f4.setDescription("12-hour simmered pork broth, tender chashu pork belly, seasoned ramen egg, menma and spring onions");
            f4.setPrice(new BigDecimal("15.25"));
            f4.setAvailable(true);
            f4.setRestaurant(r2);
            foodItemRepository.save(f4);

            FoodItem f5 = new FoodItem();
            f5.setName("Salmon Avocado Sushi Roll (8 pcs)");
            f5.setDescription("Fresh Atlantic salmon, ripe Hass avocado, Japanese sushi rice, nori and toasted white sesame");
            f5.setPrice(new BigDecimal("11.50"));
            f5.setAvailable(true);
            f5.setRestaurant(r2);
            foodItemRepository.save(f5);

            FoodItem f6 = new FoodItem();
            f6.setName("Crispy Chicken Gyoza (6 pcs)");
            f6.setDescription("Pan-seared Japanese dumplings with chicken and cabbage filling, served with citrus ponzu dip");
            f6.setPrice(new BigDecimal("7.50"));
            f6.setAvailable(true);
            f6.setRestaurant(r2);
            foodItemRepository.save(f6);

            // Restaurant 3: Gourmet Burgers
            Restaurant r3 = new Restaurant(
                    "Burger Craft & Grill",
                    "45 Gourmet Ave, Westside",
                    "555-0103",
                    "American / Grill"
            );
            r3 = restaurantRepository.save(r3);

            FoodItem f7 = new FoodItem();
            f7.setName("Double Bacon Smash Burger");
            f7.setDescription("Two smashed Angus beef patties, aged cheddar, smoky bacon, pickled relish and house secret sauce on toasted brioche");
            f7.setPrice(new BigDecimal("12.99"));
            f7.setAvailable(true);
            f7.setRestaurant(r3);
            foodItemRepository.save(f7);

            FoodItem f8 = new FoodItem();
            f8.setName("Loaded Truffle Parmesan Fries");
            f8.setDescription("Crispy golden skin-on fries tossed in white truffle oil, rosemary sea salt and finely grated parmesan");
            f8.setPrice(new BigDecimal("5.99"));
            f8.setAvailable(true);
            f8.setRestaurant(r3);
            foodItemRepository.save(f8);
        }
    }
}

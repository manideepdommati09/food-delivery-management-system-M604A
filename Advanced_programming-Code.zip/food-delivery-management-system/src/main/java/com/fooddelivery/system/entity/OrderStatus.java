package com.fooddelivery.system.entity;

public enum OrderStatus {

    PLACED,
    CONFIRMED,
    PREPARING,
    OUT_FOR_DELIVERY,
    DELIVERED,
    CANCELLED
}
package com.fooddelivery.system.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class AuthInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(
            HttpServletRequest request,
            HttpServletResponse response,
            Object handler) throws Exception {

        String path = request.getRequestURI();

        // Allow static resources
        if (path.equals("/") ||
                path.startsWith("/css/") ||
                path.startsWith("/js/") ||
                path.startsWith("/images/") ||
                path.startsWith("/index.html") ||
                path.startsWith("/favicon")) {
            return true;
        }

        // Allow auth endpoints without authentication
        if (path.startsWith("/api/auth/")) {
            return true;
        }

        // Check if user is authenticated
        HttpSession session = request.getSession(false);

        if (session == null ||
                session.getAttribute("userId") == null) {

            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.setContentType("application/json");
            response.getWriter().write(
                    "{\"message\":\"Please login first\"}");
            return false;
        }

        String role = (String) session.getAttribute("role");

        // Admin has full access
        if ("ADMIN".equals(role)) {
            return true;
        }

        // Customer role access control
        if ("CUSTOMER".equals(role)) {

            // Customers can access orders (browse, create, view my orders)
            if (path.startsWith("/api/orders")) {
                return true;
            }

            // Customers can access customer dashboard
            if (path.startsWith("/api/dashboard/customer")) {
                return true;
            }

            // Customers can view and add food items
            if (path.startsWith("/api/food-items")) {
                if ("GET".equalsIgnoreCase(request.getMethod()) || "POST".equalsIgnoreCase(request.getMethod())) {
                    return true;
                }
            }

            // Customers can view restaurants
            if (path.startsWith("/api/restaurants") &&
                    "GET".equalsIgnoreCase(request.getMethod())) {
                return true;
            }

            // Customers can view their deliveries
            if (path.startsWith("/api/deliveries") &&
                    "GET".equalsIgnoreCase(request.getMethod())) {
                return true;
            }

            // Customers can read customer profile
            if (path.startsWith("/api/customers") &&
                    "GET".equalsIgnoreCase(request.getMethod())) {
                return true;
            }

            // Block everything else for customers
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            response.setContentType("application/json");
            response.getWriter().write(
                    "{\"message\":\"Access denied\"}");
            return false;
        }

        response.setStatus(HttpServletResponse.SC_FORBIDDEN);
        response.setContentType("application/json");
        response.getWriter().write(
                "{\"message\":\"Access denied\"}");
        return false;
    }
}

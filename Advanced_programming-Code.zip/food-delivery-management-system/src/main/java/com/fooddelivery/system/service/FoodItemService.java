package com.fooddelivery.system.service;

import com.fooddelivery.system.dto.FoodItemRequest;
import com.fooddelivery.system.entity.FoodItem;
import com.fooddelivery.system.entity.Restaurant;
import com.fooddelivery.system.exception.ResourceNotFoundException;
import com.fooddelivery.system.repository.FoodItemRepository;
import com.fooddelivery.system.repository.RestaurantRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FoodItemService {

    private final FoodItemRepository foodItemRepository;
    private final RestaurantRepository restaurantRepository;

    public FoodItemService(
            FoodItemRepository foodItemRepository,
            RestaurantRepository restaurantRepository) {

        this.foodItemRepository = foodItemRepository;
        this.restaurantRepository = restaurantRepository;
    }

    public List<FoodItem> getAllFoodItems() {
        return foodItemRepository.findAll();
    }

    public FoodItem getFoodItemById(Long id) {
        return foodItemRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Food item not found with ID: " + id));
    }

    public FoodItem createFoodItem(FoodItemRequest request) {

        Restaurant restaurant = restaurantRepository
                .findById(request.getRestaurantId())
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Restaurant not found with ID: "
                                        + request.getRestaurantId()));

        FoodItem foodItem = new FoodItem();

        foodItem.setName(request.getName());
        foodItem.setDescription(request.getDescription());
        foodItem.setPrice(request.getPrice());
        foodItem.setAvailable(request.isAvailable());
        foodItem.setRestaurant(restaurant);

        return foodItemRepository.save(foodItem);
    }

    public FoodItem updateFoodItem(
            Long id,
            FoodItemRequest request) {

        FoodItem foodItem = getFoodItemById(id);

        Restaurant restaurant = restaurantRepository
                .findById(request.getRestaurantId())
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Restaurant not found with ID: "
                                        + request.getRestaurantId()));

        foodItem.setName(request.getName());
        foodItem.setDescription(request.getDescription());
        foodItem.setPrice(request.getPrice());
        foodItem.setAvailable(request.isAvailable());
        foodItem.setRestaurant(restaurant);

        return foodItemRepository.save(foodItem);
    }

    public void deleteFoodItem(Long id) {

        FoodItem foodItem = getFoodItemById(id);

        foodItemRepository.delete(foodItem);
    }
}
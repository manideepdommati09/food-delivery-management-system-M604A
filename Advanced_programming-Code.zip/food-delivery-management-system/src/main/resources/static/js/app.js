/**
 * SwiftBite Food Delivery Management System
 * Full SPA Controller: Auth, Admin User Management, Customer Food Ordering, Live Cart & Tracking
 */

const API_BASE = "/api";

// Global App State
let currentUser = null;
let currentRole = null;
let cart = [];
let allFoodItems = [];
let allRestaurants = [];
let allCustomers = [];
let allUsers = [];
let allOrders = [];
let allDeliveries = [];
let selectedRestaurantFilter = "ALL";

/* ==========================================================================
   INITIALIZATION & AUTH CHECK
   ========================================================================== */

document.addEventListener("DOMContentLoaded", async () => {
    loadSavedCart();
    await checkAuthSession();
});

async function checkAuthSession() {
    try {
        const response = await fetch(`${API_BASE}/auth/me`, {
            method: "GET",
            cache: "no-store"
        });

        if (response.ok) {
            const user = await response.json();
            currentUser = user;
            currentRole = user.role;
            initAuthenticatedApp();
        } else {
            showAuthScreen();
        }
    } catch (err) {
        console.warn("Session check failed, showing login", err);
        showAuthScreen();
    }
}

function showAuthScreen() {
    currentUser = null;
    currentRole = null;
    document.getElementById("authScreen").classList.remove("hidden");
    document.getElementById("appScreen").classList.add("hidden");
}

function initAuthenticatedApp() {
    document.getElementById("authScreen").classList.add("hidden");
    document.getElementById("appScreen").classList.remove("hidden");

    // Update Topbar Info
    const usernameEl = document.getElementById("topbarUsername");
    const roleLabelEl = document.getElementById("topbarRoleLabel");
    const avatarEl = document.getElementById("userAvatarText");
    const roleBadgeContainer = document.getElementById("roleBadgeContainer");

    const displayName = currentUser.customerName || currentUser.username || "User";
    usernameEl.textContent = displayName;
    roleLabelEl.textContent = currentRole;
    avatarEl.textContent = displayName.charAt(0).toUpperCase();

    // Render Role Badge
    if (currentRole === "ADMIN") {
        roleBadgeContainer.innerHTML = `<span class="badge-role admin">👑 Admin Access</span>`;
        document.getElementById("adminNav").classList.remove("hidden");
        document.getElementById("customerNav").classList.add("hidden");
        document.getElementById("topbarCartBtn").classList.add("hidden");
        showSection("adminDashboard");
    } else {
        roleBadgeContainer.innerHTML = `<span class="badge-role customer">👤 Customer App</span>`;
        document.getElementById("adminNav").classList.add("hidden");
        document.getElementById("customerNav").classList.remove("hidden");
        document.getElementById("topbarCartBtn").classList.remove("hidden");
        updateCartBadge();
        showSection("browseFood");
    }

    // Populate common select elements
    populateRestaurantSelects();
}

/* ==========================================================================
   AUTH: LOGIN, REGISTER, LOGOUT
   ========================================================================== */

function switchAuthTab(tab) {
    const loginTabBtn = document.getElementById("tabLoginBtn");
    const regTabBtn = document.getElementById("tabRegisterBtn");
    const loginForm = document.getElementById("loginForm");
    const regForm = document.getElementById("registerForm");

    if (tab === "login") {
        loginTabBtn.classList.add("active");
        regTabBtn.classList.remove("active");
        loginForm.classList.remove("hidden");
        regForm.classList.add("hidden");
    } else {
        regTabBtn.classList.add("active");
        loginTabBtn.classList.remove("active");
        regForm.classList.remove("hidden");
        loginForm.classList.add("hidden");
    }
}

function togglePasswordVisibility(fieldId) {
    const input = document.getElementById(fieldId);
    if (input) {
        input.type = input.type === "password" ? "text" : "password";
    }
}

function fillAndLogin(username, password) {
    switchAuthTab("login");
    document.getElementById("loginUsername").value = username;
    document.getElementById("loginPassword").value = password;
    
    // Automatically submit
    const submitBtn = document.getElementById("loginSubmitBtn");
    if (submitBtn) {
        submitBtn.click();
    }
}

async function handleLogin(e) {
    e.preventDefault();
    const usernameInput = document.getElementById("loginUsername").value.trim();
    const passwordInput = document.getElementById("loginPassword").value;

    const submitBtn = document.getElementById("loginSubmitBtn");
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = `<span>Signing In...</span>`;
    submitBtn.disabled = true;

    try {
        const response = await fetch(`${API_BASE}/auth/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username: usernameInput, password: passwordInput })
        });

        const data = await response.json();

        if (response.ok) {
            currentUser = data;
            currentRole = data.role;
            showToast(`Welcome back, ${data.username}!`, "success");
            initAuthenticatedApp();
        } else {
            showToast(data.message || "Invalid credentials", "error");
        }
    } catch (err) {
        console.error("Login error:", err);
        showToast("Unable to connect to server. Please try again.", "error");
    } finally {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
}

async function handleRegister(e) {
    e.preventDefault();
    const name = document.getElementById("regName").value.trim();
    const username = document.getElementById("regUsername").value.trim();
    const email = document.getElementById("regEmail").value.trim();
    const phone = document.getElementById("regPhone").value.trim();
    const address = document.getElementById("regAddress").value.trim();
    const password = document.getElementById("regPassword").value;

    const submitBtn = document.getElementById("regSubmitBtn");
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = `<span>Creating Account...</span>`;
    submitBtn.disabled = true;

    try {
        const response = await fetch(`${API_BASE}/auth/register`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, username, email, phone, address, password })
        });

        const data = await response.json();

        if (response.ok) {
            showToast("Registration successful! Logging you in...", "success");
            // Auto-login with the newly created account
            fillAndLogin(username, password);
        } else {
            showToast(data.message || "Registration failed. Try a different username.", "error");
        }
    } catch (err) {
        console.error("Register error:", err);
        showToast("Error registering account.", "error");
    } finally {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
}

async function handleLogout() {
    try {
        await fetch(`${API_BASE}/auth/logout`, { method: "POST" });
    } catch (err) {
        console.warn("Logout request failed:", err);
    }
    showToast("Logged out successfully.", "info");
    showAuthScreen();
}

/* ==========================================================================
   NAVIGATION & SECTION SWITCHING
   ========================================================================== */

function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll(".page-section").forEach(sec => sec.classList.remove("active"));
    
    // Deactivate all nav items
    document.querySelectorAll(".nav-item").forEach(item => {
        if (item.getAttribute("data-section") === sectionId) {
            item.classList.add("active");
        } else {
            item.classList.remove("active");
        }
    });

    const targetSec = document.getElementById(sectionId);
    if (targetSec) {
        targetSec.classList.add("active");
    }

    // Trigger section-specific data loads
    switch (sectionId) {
        // Admin sections
        case "adminDashboard":
            loadAdminDashboard();
            break;
        case "users":
            loadUsers();
            break;
        case "customers":
            loadCustomers();
            break;
        case "restaurants":
            loadRestaurants();
            break;
        case "foodItems":
            loadFoodItems();
            break;
        case "orders":
            loadOrders();
            break;
        case "deliveries":
            loadDeliveries();
            break;

        // Customer sections
        case "browseFood":
            loadCustomerBrowseFood();
            break;
        case "cartCheckout":
            renderCart();
            break;
        case "myOrders":
            loadMyOrders();
            break;
        case "customerProfile":
            loadCustomerProfile();
            break;
    }
}

/* ==========================================================================
   GENERIC API HELPER
   ========================================================================== */

async function apiFetch(endpoint, options = {}) {
    const url = endpoint.startsWith("http") ? endpoint : `${API_BASE}${endpoint}`;
    const defaultHeaders = { "Content-Type": "application/json" };
    
    const config = {
        ...options,
        headers: {
            ...defaultHeaders,
            ...(options.headers || {})
        }
    };

    const res = await fetch(url, config);
    if (!res.ok) {
        let errMessage = `Error ${res.status}`;
        try {
            const errData = await res.json();
            errMessage = errData.message || JSON.stringify(errData);
        } catch (_) {}
        throw new Error(errMessage);
    }

    if (res.status === 204) return null; // No content
    return await res.json();
}

/* ==========================================================================
   ADMIN: DASHBOARD
   ========================================================================== */

async function loadAdminDashboard() {
    try {
        const stats = await apiFetch("/dashboard/admin");
        document.getElementById("dashRevenue").textContent = `£${Number(stats.totalRevenue || 0).toFixed(2)}`;
        document.getElementById("dashActiveOrders").textContent = stats.activeOrders || 0;
        document.getElementById("dashCustomerCount").textContent = stats.customerCount || 0;
        document.getElementById("dashRestaurantCount").textContent = stats.restaurantCount || 0;
        document.getElementById("dashFoodCount").textContent = stats.foodItemCount || 0;
        document.getElementById("dashDeliveryCount").textContent = stats.deliveryCount || 0;
    } catch (err) {
        console.error("Dashboard error:", err);
    }
}

/* ==========================================================================
   ADMIN: USERS MANAGEMENT (NEW FEATURE)
   ========================================================================== */

async function loadUsers() {
    try {
        allUsers = await apiFetch("/users");
        renderUsersTable(allUsers);
    } catch (err) {
        console.error("Load users error:", err);
        showToast("Failed to load users: " + err.message, "error");
    }
}

function renderUsersTable(users) {
    const tbody = document.getElementById("usersTableBody");
    const countDisplay = document.getElementById("usersCountDisplay");
    tbody.innerHTML = "";
    countDisplay.textContent = `${users.length} Users`;

    if (users.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" class="empty-table-state"><span class="empty-icon">👥</span>No users found.</td></tr>`;
        return;
    }

    users.forEach(u => {
        const roleBadge = u.role === "ADMIN" 
            ? `<span class="badge-role admin">👑 ADMIN</span>` 
            : `<span class="badge-role customer">👤 CUSTOMER</span>`;

        const custName = u.customer ? u.customer.name : `<span class="text-dim">N/A (Admin)</span>`;
        const custEmail = u.customer ? u.customer.email : `<span class="text-dim">-</span>`;
        const custPhone = u.customer ? u.customer.phone : `<span class="text-dim">-</span>`;

        const deleteBtn = u.username === "admin"
            ? `<span class="text-dim" title="System Admin cannot be deleted">System</span>`
            : `<button type="button" class="btn-sm-danger" onclick="deleteUser(${u.id}, '${u.username}')">Delete</button>`;

        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>#${u.id}</td>
            <td><strong>${u.username}</strong></td>
            <td>${roleBadge}</td>
            <td>${custName}</td>
            <td>${custEmail}</td>
            <td>${custPhone}</td>
            <td>${deleteBtn}</td>
        `;
        tbody.appendChild(tr);
    });
}

function filterUsersTable() {
    const q = document.getElementById("userSearchInput").value.toLowerCase();
    const filtered = allUsers.filter(u => 
        u.username.toLowerCase().includes(q) ||
        u.role.toLowerCase().includes(q) ||
        (u.customer && u.customer.name.toLowerCase().includes(q)) ||
        (u.customer && u.customer.email.toLowerCase().includes(q))
    );
    renderUsersTable(filtered);
}

async function handleAddUser(e) {
    e.preventDefault();
    const username = document.getElementById("newUsername").value.trim();
    const password = document.getElementById("newUserPassword").value;
    const role = document.getElementById("newUserRole").value;
    const name = document.getElementById("newUserName").value.trim();
    const email = document.getElementById("newUserEmail").value.trim();
    const phone = document.getElementById("newUserPhone").value.trim();
    const address = document.getElementById("newUserAddress").value.trim();

    try {
        await apiFetch("/users", {
            method: "POST",
            body: JSON.stringify({ username, password, role, name, email, phone, address })
        });
        showToast(`User account "${username}" created successfully!`, "success");
        closeModal("modalAddUser");
        document.getElementById("addUserForm").reset();
        await loadUsers();
    } catch (err) {
        showToast(err.message || "Failed to create user", "error");
    }
}

async function deleteUser(id, username) {
    if (!confirm(`Are you sure you want to delete user "${username}"?`)) return;

    try {
        await apiFetch(`/users/${id}`, { method: "DELETE" });
        showToast(`User "${username}" deleted`, "info");
        await loadUsers();
    } catch (err) {
        showToast(err.message || "Failed to delete user", "error");
    }
}

/* ==========================================================================
   ADMIN: CUSTOMERS
   ========================================================================== */

async function loadCustomers() {
    try {
        allCustomers = await apiFetch("/customers");
        renderCustomersTable(allCustomers);
    } catch (err) {
        console.error("Load customers error:", err);
    }
}

function renderCustomersTable(customers) {
    const tbody = document.getElementById("customerTableBody");
    const countDisplay = document.getElementById("customersCountDisplay");
    tbody.innerHTML = "";
    countDisplay.textContent = `${customers.length} Customers`;

    if (customers.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="empty-table-state"><span class="empty-icon">👤</span>No customers registered yet.</td></tr>`;
        return;
    }

    customers.forEach(c => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>#${c.id}</td>
            <td><strong>${c.name}</strong></td>
            <td>${c.email}</td>
            <td>${c.phone}</td>
            <td>${c.address}</td>
            <td>
                <button type="button" class="btn-sm-danger" onclick="deleteCustomer(${c.id}, '${c.name}')">Delete</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function filterCustomersTable() {
    const q = document.getElementById("customerSearchInput").value.toLowerCase();
    const filtered = allCustomers.filter(c => 
        c.name.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q) ||
        c.phone.toLowerCase().includes(q)
    );
    renderCustomersTable(filtered);
}

async function handleAddCustomer(e) {
    e.preventDefault();
    const name = document.getElementById("newCustName").value.trim();
    const email = document.getElementById("newCustEmail").value.trim();
    const phone = document.getElementById("newCustPhone").value.trim();
    const address = document.getElementById("newCustAddress").value.trim();

    try {
        await apiFetch("/customers", {
            method: "POST",
            body: JSON.stringify({ name, email, phone, address })
        });
        showToast(`Customer "${name}" created!`, "success");
        closeModal("modalAddCustomer");
        document.getElementById("addCustomerForm").reset();
        await loadCustomers();
    } catch (err) {
        showToast(err.message || "Failed to create customer", "error");
    }
}

async function deleteCustomer(id, name) {
    if (!confirm(`Are you sure you want to delete customer "${name}"?`)) return;

    try {
        await apiFetch(`/customers/${id}`, { method: "DELETE" });
        showToast(`Customer "${name}" deleted.`, "info");
        await loadCustomers();
    } catch (err) {
        showToast(err.message || "Unable to delete customer. Ensure no active orders are linked.", "error");
    }
}

/* ==========================================================================
   ADMIN: RESTAURANTS
   ========================================================================== */

async function loadRestaurants() {
    try {
        allRestaurants = await apiFetch("/restaurants");
        renderRestaurantsTable(allRestaurants);
        populateRestaurantSelects();
    } catch (err) {
        console.error("Load restaurants error:", err);
    }
}

function renderRestaurantsTable(restaurants) {
    const tbody = document.getElementById("restaurantTableBody");
    const countDisplay = document.getElementById("restaurantsCountDisplay");
    tbody.innerHTML = "";
    countDisplay.textContent = `${restaurants.length} Restaurants`;

    if (restaurants.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="empty-table-state"><span class="empty-icon">🏪</span>No restaurants added yet.</td></tr>`;
        return;
    }

    restaurants.forEach(r => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>#${r.id}</td>
            <td><strong>${r.name}</strong></td>
            <td><span class="status-pill status-assigned">${r.cuisineType}</span></td>
            <td>${r.address}</td>
            <td>${r.phone}</td>
            <td>
                <button type="button" class="btn-sm-danger" onclick="deleteRestaurant(${r.id}, '${r.name}')">Delete</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function filterRestaurantsTable() {
    const q = document.getElementById("restaurantSearchInput").value.toLowerCase();
    const filtered = allRestaurants.filter(r => 
        r.name.toLowerCase().includes(q) ||
        r.cuisineType.toLowerCase().includes(q) ||
        r.address.toLowerCase().includes(q)
    );
    renderRestaurantsTable(filtered);
}

async function handleAddRestaurant(e) {
    e.preventDefault();
    const name = document.getElementById("newRestName").value.trim();
    const cuisineType = document.getElementById("newRestCuisine").value.trim();
    const phone = document.getElementById("newRestPhone").value.trim();
    const address = document.getElementById("newRestAddress").value.trim();

    try {
        await apiFetch("/restaurants", {
            method: "POST",
            body: JSON.stringify({ name, cuisineType, phone, address })
        });
        showToast(`Restaurant "${name}" added successfully!`, "success");
        closeModal("modalAddRestaurant");
        document.getElementById("addRestaurantForm").reset();
        await loadRestaurants();
    } catch (err) {
        showToast(err.message || "Failed to add restaurant", "error");
    }
}

async function deleteRestaurant(id, name) {
    if (!confirm(`Are you sure you want to delete restaurant "${name}"?`)) return;

    try {
        await apiFetch(`/restaurants/${id}`, { method: "DELETE" });
        showToast(`Restaurant "${name}" removed.`, "info");
        await loadRestaurants();
    } catch (err) {
        showToast(err.message || "Failed to delete restaurant. Check linked food items.", "error");
    }
}

/* ==========================================================================
   FOOD CATALOG MANAGEMENT (ADMIN & CUSTOMER ADD DISHES)
   ========================================================================== */

async function loadFoodItems() {
    try {
        allFoodItems = await apiFetch("/food-items");
        renderFoodTable(allFoodItems);
    } catch (err) {
        console.error("Load food items error:", err);
    }
}

function renderFoodTable(items) {
    const tbody = document.getElementById("foodTableBody");
    const countDisplay = document.getElementById("foodCountDisplay");
    tbody.innerHTML = "";
    countDisplay.textContent = `${items.length} Items`;

    if (items.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="empty-table-state"><span class="empty-icon">🍔</span>No food items in catalog.</td></tr>`;
        return;
    }

    items.forEach(f => {
        const restName = f.restaurant ? f.restaurant.name : "N/A";
        const availBadge = f.available 
            ? `<span class="badge-avail-yes">✓ Available</span>` 
            : `<span class="badge-avail-no">✕ Out of Stock</span>`;

        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>#${f.id}</td>
            <td>
                <strong>${f.name}</strong>
                <br><small class="text-dim">${f.description || ""}</small>
            </td>
            <td><span class="status-pill status-assigned">${restName}</span></td>
            <td><strong class="text-amber">£${Number(f.price).toFixed(2)}</strong></td>
            <td>${availBadge}</td>
            <td>
                <button type="button" class="btn-sm-danger" onclick="deleteFoodItem(${f.id}, '${f.name}')">Delete</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function filterFoodTable() {
    const q = document.getElementById("foodSearchInput").value.toLowerCase();
    const restId = document.getElementById("foodRestaurantFilter").value;

    const filtered = allFoodItems.filter(f => {
        const matchesQuery = f.name.toLowerCase().includes(q) || (f.description && f.description.toLowerCase().includes(q));
        const matchesRest = !restId || (f.restaurant && f.restaurant.id.toString() === restId);
        return matchesQuery && matchesRest;
    });

    renderFoodTable(filtered);
}

async function handleAddFoodItem(e) {
    e.preventDefault();
    const name = document.getElementById("newFoodName").value.trim();
    const description = document.getElementById("newFoodDescription").value.trim();
    const price = Number(document.getElementById("newFoodPrice").value);
    const restaurantId = Number(document.getElementById("newFoodRestaurantId").value);
    const available = document.getElementById("newFoodAvailable").checked;

    try {
        await apiFetch("/food-items", {
            method: "POST",
            body: JSON.stringify({ name, description, price, restaurantId, available })
        });
        showToast(`Food dish "${name}" added to menu!`, "success");
        closeModal("modalAddFood");
        document.getElementById("addFoodForm").reset();
        
        // Refresh catalog
        if (currentRole === "ADMIN") {
            await loadFoodItems();
        } else {
            await loadCustomerBrowseFood();
        }
    } catch (err) {
        showToast(err.message || "Failed to add food item", "error");
    }
}

async function deleteFoodItem(id, name) {
    if (!confirm(`Are you sure you want to delete food item "${name}"?`)) return;

    try {
        await apiFetch(`/food-items/${id}`, { method: "DELETE" });
        showToast(`Food item "${name}" deleted.`, "info");
        await loadFoodItems();
    } catch (err) {
        showToast(err.message || "Failed to delete food item", "error");
    }
}

/* ==========================================================================
   ADMIN: ORDERS LEDGER & STATUS UPDATE
   ========================================================================== */

async function loadOrders() {
    try {
        allOrders = await apiFetch("/orders");
        renderOrdersTable(allOrders);
    } catch (err) {
        console.error("Load orders error:", err);
    }
}

function renderOrdersTable(orders) {
    const tbody = document.getElementById("ordersTableBody");
    const countDisplay = document.getElementById("ordersCountDisplay");
    tbody.innerHTML = "";
    countDisplay.textContent = `${orders.length} Orders`;

    if (orders.length === 0) {
        tbody.innerHTML = `<tr><td colspan="8" class="empty-table-state"><span class="empty-icon">📦</span>No orders found.</td></tr>`;
        return;
    }

    orders.forEach(o => {
        const customerName = o.customer ? o.customer.name : "Guest";
        const restaurantName = o.restaurant ? o.restaurant.name : "N/A";
        const formattedDate = o.orderDate ? new Date(o.orderDate).toLocaleString() : "-";
        const total = Number(o.totalAmount || 0).toFixed(2);

        const statusOptions = ["PLACED", "PREPARING", "OUT_FOR_DELIVERY", "DELIVERED", "CANCELLED"]
            .map(s => `<option value="${s}" ${o.status === s ? "selected" : ""}>${s}</option>`)
            .join("");

        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td><strong>#${o.id}</strong></td>
            <td>${customerName}</td>
            <td>${restaurantName}</td>
            <td>${formattedDate}</td>
            <td><strong class="text-amber">£${total}</strong></td>
            <td>
                <select class="table-select" onchange="changeOrderStatus(${o.id}, this.value)">
                    ${statusOptions}
                </select>
            </td>
            <td><small>${o.deliveryAddress}</small></td>
            <td>
                <div style="display: flex; gap: 6px;">
                    <button type="button" class="btn-sm-action" onclick="viewOrderDetails(${o.id})">Items (${o.items ? o.items.length : 0})</button>
                    <button type="button" class="btn-sm-danger" onclick="deleteOrder(${o.id})">Delete</button>
                </div>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function filterOrdersTable() {
    const q = document.getElementById("orderSearchInput").value.toLowerCase();
    const statusFilter = document.getElementById("orderStatusFilter").value;

    const filtered = allOrders.filter(o => {
        const matchesQuery = o.id.toString().includes(q) ||
            (o.customer && o.customer.name.toLowerCase().includes(q)) ||
            (o.restaurant && o.restaurant.name.toLowerCase().includes(q)) ||
            (o.deliveryAddress && o.deliveryAddress.toLowerCase().includes(q));
        const matchesStatus = !statusFilter || o.status === statusFilter;
        return matchesQuery && matchesStatus;
    });

    renderOrdersTable(filtered);
}

async function changeOrderStatus(orderId, newStatus) {
    try {
        await apiFetch(`/orders/${orderId}/status?status=${newStatus}`, { method: "PUT" });
        showToast(`Order #${orderId} status updated to ${newStatus}`, "success");
        await loadOrders();
    } catch (err) {
        showToast(err.message || "Failed to update order status", "error");
    }
}

function viewOrderDetails(orderId) {
    const order = allOrders.find(o => o.id === orderId);
    if (!order) return;

    const content = document.getElementById("orderDetailsContent");
    const itemsHtml = (order.items || []).map(item => {
        const foodName = item.foodItem ? item.foodItem.name : `Food #${item.foodItemId || ''}`;
        const itemPrice = Number(item.price || 0).toFixed(2);
        const subtotal = (Number(item.price || 0) * Number(item.quantity || 1)).toFixed(2);

        return `
            <div class="summary-row" style="padding: 10px 0; border-bottom: 1px solid var(--border-subtle);">
                <div>
                    <strong>${foodName}</strong>
                    <br><small class="text-dim">£${itemPrice} × ${item.quantity}</small>
                </div>
                <strong>£${subtotal}</strong>
            </div>
        `;
    }).join("");

    content.innerHTML = `
        <div style="margin-bottom: 16px;">
            <h4>Order #${order.id} • <span class="text-amber">£${Number(order.totalAmount || 0).toFixed(2)}</span></h4>
            <p class="text-dim" style="font-size: 13px; margin-top: 4px;">
                Customer: <strong>${order.customer?.name || 'N/A'}</strong> | Restaurant: <strong>${order.restaurant?.name || 'N/A'}</strong>
            </p>
            <p class="text-dim" style="font-size: 13px;">
                Delivery Destination: <strong>${order.deliveryAddress}</strong>
            </p>
        </div>
        <div style="background: var(--bg-surface); padding: 16px; border-radius: var(--radius-md);">
            <div style="font-size: 12px; font-weight: 700; color: var(--text-dim); margin-bottom: 8px; text-transform: uppercase;">
                Ordered Items
            </div>
            ${itemsHtml || '<p class="text-dim">No items found</p>'}
        </div>
    `;

    openModal("modalOrderDetails");
}

async function deleteOrder(id) {
    if (!confirm(`Are you sure you want to delete order #${id}?`)) return;

    try {
        await apiFetch(`/orders/${id}`, { method: "DELETE" });
        showToast(`Order #${id} deleted`, "info");
        await loadOrders();
    } catch (err) {
        showToast(err.message || "Failed to delete order", "error");
    }
}

/* ==========================================================================
   ADMIN: DELIVERIES FLEET
   ========================================================================== */

async function loadDeliveries() {
    try {
        allDeliveries = await apiFetch("/deliveries");
        renderDeliveriesTable(allDeliveries);
        populatePendingOrdersSelect();
    } catch (err) {
        console.error("Load deliveries error:", err);
    }
}

function renderDeliveriesTable(deliveries) {
    const tbody = document.getElementById("deliveriesTableBody");
    const countDisplay = document.getElementById("deliveriesCountDisplay");
    tbody.innerHTML = "";
    countDisplay.textContent = `${deliveries.length} Deliveries`;

    if (deliveries.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" class="empty-table-state"><span class="empty-icon">🚚</span>No deliveries assigned yet.</td></tr>`;
        return;
    }

    deliveries.forEach(d => {
        const orderId = d.order ? d.order.id : "N/A";
        const deliveryTime = d.deliveryTime ? new Date(d.deliveryTime).toLocaleString() : `<span class="text-dim">In Progress</span>`;

        const statusOptions = ["ASSIGNED", "IN_TRANSIT", "DELIVERED"]
            .map(s => `<option value="${s}" ${d.deliveryStatus === s ? "selected" : ""}>${s}</option>`)
            .join("");

        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td><strong>#${d.id}</strong></td>
            <td><button class="btn-sm-action" onclick="viewOrderDetails(${orderId})">Order #${orderId}</button></td>
            <td><strong>${d.deliveryPerson}</strong></td>
            <td>
                <select class="table-select" onchange="changeDeliveryStatus(${d.id}, this.value)">
                    ${statusOptions}
                </select>
            </td>
            <td>${deliveryTime}</td>
        `;
        tbody.appendChild(tr);
    });
}

function filterDeliveriesTable() {
    const q = document.getElementById("deliverySearchInput").value.toLowerCase();
    const filtered = allDeliveries.filter(d => 
        d.id.toString().includes(q) ||
        d.deliveryPerson.toLowerCase().includes(q) ||
        (d.order && d.order.id.toString().includes(q))
    );
    renderDeliveriesTable(filtered);
}

async function changeDeliveryStatus(deliveryId, newStatus) {
    try {
        await apiFetch(`/deliveries/${deliveryId}/status?status=${newStatus}`, { method: "PUT" });
        showToast(`Delivery #${deliveryId} status updated to ${newStatus}`, "success");
        await loadDeliveries();
    } catch (err) {
        showToast(err.message || "Failed to update delivery status", "error");
    }
}

async function handleAssignDelivery(e) {
    e.preventDefault();
    const orderId = document.getElementById("deliveryOrderId").value;
    const deliveryPerson = document.getElementById("deliveryPersonName").value.trim();

    try {
        await apiFetch(`/deliveries?orderId=${orderId}&deliveryPerson=${encodeURIComponent(deliveryPerson)}`, {
            method: "POST"
        });
        showToast(`Delivery driver "${deliveryPerson}" assigned to Order #${orderId}!`, "success");
        closeModal("modalAssignDelivery");
        document.getElementById("assignDeliveryForm").reset();
        await loadDeliveries();
    } catch (err) {
        showToast(err.message || "Failed to assign delivery", "error");
    }
}

async function populatePendingOrdersSelect() {
    try {
        const orders = await apiFetch("/orders");
        const select = document.getElementById("deliveryOrderId");
        select.innerHTML = `<option value="">Choose Pending Order...</option>`;
        
        orders.filter(o => o.status !== "DELIVERED" && o.status !== "CANCELLED").forEach(o => {
            select.innerHTML += `<option value="${o.id}">Order #${o.id} - ${o.customer?.name || 'Customer'} (£${Number(o.totalAmount).toFixed(2)})</option>`;
        });
    } catch (_) {}
}

/* ==========================================================================
   CUSTOMER: BROWSE FOOD & ORDER
   ========================================================================== */

async function loadCustomerBrowseFood() {
    try {
        const [foodData, restData] = await Promise.all([
            apiFetch("/food-items"),
            apiFetch("/restaurants")
        ]);

        allFoodItems = foodData;
        allRestaurants = restData;

        renderRestaurantFilterPills();
        renderCustomerFoodCards();
    } catch (err) {
        console.error("Browse food error:", err);
    }
}

function renderRestaurantFilterPills() {
    const container = document.getElementById("restaurantFilterPills");
    container.innerHTML = `
        <button class="pill-btn ${selectedRestaurantFilter === 'ALL' ? 'active' : ''}" onclick="setRestaurantFilter('ALL', this)">
            All Menus
        </button>
    `;

    allRestaurants.forEach(r => {
        const isActive = selectedRestaurantFilter === r.id.toString();
        const btn = document.createElement("button");
        btn.className = `pill-btn ${isActive ? 'active' : ''}`;
        btn.textContent = `${r.name} (${r.cuisineType})`;
        btn.onclick = () => setRestaurantFilter(r.id.toString(), btn);
        container.appendChild(btn);
    });
}

function setRestaurantFilter(filterVal, btnElement) {
    selectedRestaurantFilter = filterVal;
    document.querySelectorAll(".pill-btn").forEach(b => b.classList.remove("active"));
    if (btnElement) btnElement.classList.add("active");
    renderCustomerFoodCards();
}

function getFoodEmoji(name = "") {
    const lower = name.toLowerCase();
    if (lower.includes("pizza")) return "🍕";
    if (lower.includes("burger")) return "🍔";
    if (lower.includes("ramen") || lower.includes("noodle")) return "🍜";
    if (lower.includes("sushi") || lower.includes("roll")) return "🍣";
    if (lower.includes("pasta") || lower.includes("lasagna")) return "🍝";
    if (lower.includes("fries")) return "🍟";
    if (lower.includes("chicken") || lower.includes("curry") || lower.includes("tikka")) return "🍗";
    if (lower.includes("tiramisu") || lower.includes("cake") || lower.includes("dessert")) return "🍰";
    if (lower.includes("shake") || lower.includes("drink")) return "🥤";
    if (lower.includes("gyoza") || lower.includes("dumpling")) return "🥟";
    if (lower.includes("taco") || lower.includes("burrito")) return "🌮";
    if (lower.includes("salad")) return "🥗";
    return "🍱";
}

function renderCustomerFoodCards() {
    const grid = document.getElementById("customerFoodGrid");
    const searchQuery = (document.getElementById("customerFoodSearch")?.value || "").toLowerCase();

    const filtered = allFoodItems.filter(item => {
        const matchesQuery = item.name.toLowerCase().includes(searchQuery) ||
            (item.description && item.description.toLowerCase().includes(searchQuery)) ||
            (item.restaurant && item.restaurant.name.toLowerCase().includes(searchQuery));

        const matchesRestaurant = selectedRestaurantFilter === "ALL" ||
            (item.restaurant && item.restaurant.id.toString() === selectedRestaurantFilter);

        return matchesQuery && matchesRestaurant;
    });

    grid.innerHTML = "";

    if (filtered.length === 0) {
        grid.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px;">
                <span style="font-size: 48px; display: block; margin-bottom: 12px;">🔍</span>
                <h3 style="color: white; margin-bottom: 6px;">No food items matched your search</h3>
                <p class="text-dim">Try different search keywords or add a custom food item!</p>
            </div>
        `;
        return;
    }

    filtered.forEach(item => {
        const emoji = getFoodEmoji(item.name);
        const restName = item.restaurant ? item.restaurant.name : "Chef's Kitchen";
        const price = Number(item.price).toFixed(2);
        const isAvail = item.available;

        const card = document.createElement("div");
        card.className = "food-card";
        card.innerHTML = `
            <div class="food-card-header">
                <span class="food-emoji-large">${emoji}</span>
                <span class="food-rest-tag">🏪 ${restName}</span>
                <span class="food-avail-tag ${isAvail ? 'badge-avail-yes' : 'badge-avail-no'}">
                    ${isAvail ? 'Fresh & Ready' : 'Sold Out'}
                </span>
            </div>
            <div class="food-card-body">
                <h3 class="food-card-title">${item.name}</h3>
                <p class="food-card-desc">${item.description || "Freshly cooked to order with finest local ingredients."}</p>
                <div class="food-card-footer">
                    <div class="food-price">£${price}</div>
                    <button type="button" class="add-cart-btn" ${!isAvail ? 'disabled' : ''} onclick="addToCart(${item.id})">
                        <span>🛒 Add to Cart</span>
                    </button>
                </div>
            </div>
        `;
        grid.appendChild(card);
    });
}

/* ==========================================================================
   CUSTOMER: CART & CHECKOUT
   ========================================================================== */

function loadSavedCart() {
    try {
        const saved = localStorage.getItem("swiftbite_cart");
        if (saved) {
            cart = JSON.parse(saved);
        }
    } catch (_) {
        cart = [];
    }
    updateCartBadge();
}

function saveCart() {
    try {
        localStorage.setItem("swiftbite_cart", JSON.stringify(cart));
    } catch (_) {}
    updateCartBadge();
}

function addToCart(foodId) {
    const foodItem = allFoodItems.find(f => f.id === foodId);
    if (!foodItem) return;

    const existing = cart.find(c => c.foodItem.id === foodId);
    if (existing) {
        existing.quantity += 1;
    } else {
        cart.push({ foodItem, quantity: 1 });
    }

    saveCart();
    showToast(`Added 1x ${foodItem.name} to cart!`, "success");
}

function updateCartQty(foodId, delta) {
    const itemIndex = cart.findIndex(c => c.foodItem.id === foodId);
    if (itemIndex > -1) {
        cart[itemIndex].quantity += delta;
        if (cart[itemIndex].quantity <= 0) {
            cart.splice(itemIndex, 1);
        }
        saveCart();
        renderCart();
    }
}

function removeFromCart(foodId) {
    cart = cart.filter(c => c.foodItem.id !== foodId);
    saveCart();
    renderCart();
}

function clearCart() {
    if (cart.length === 0) return;
    cart = [];
    saveCart();
    renderCart();
    showToast("Cart cleared", "info");
}

function updateCartBadge() {
    const totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
    const subtotal = cart.reduce((sum, item) => sum + (Number(item.foodItem.price) * item.quantity), 0);

    const badgeCountEl = document.getElementById("cartCountBadge");
    const bannerCartCount = document.getElementById("bannerCartCount");
    const navCartCount = document.getElementById("navCartCount");
    const totalBadgeEl = document.getElementById("cartTotalBadge");

    if (badgeCountEl) badgeCountEl.textContent = totalCount;
    if (bannerCartCount) bannerCartCount.textContent = totalCount;
    if (navCartCount) navCartCount.textContent = totalCount;
    if (totalBadgeEl) totalBadgeEl.textContent = `£${subtotal.toFixed(2)}`;
}

function renderCart() {
    updateCartBadge();
    const container = document.getElementById("cartItemsContainer");
    const countText = document.getElementById("cartItemsCountText");
    const subtotalText = document.getElementById("cartSubtotalText");
    const deliveryFeeText = document.getElementById("cartDeliveryFeeText");
    const grandTotalText = document.getElementById("cartGrandTotalText");
    const addressInput = document.getElementById("checkoutAddress");

    const totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
    const subtotal = cart.reduce((sum, item) => sum + (Number(item.foodItem.price) * item.quantity), 0);
    const deliveryFee = subtotal > 0 ? (subtotal >= 25 ? 0 : 2.50) : 0;
    const grandTotal = subtotal + deliveryFee;

    countText.textContent = totalCount;
    subtotalText.textContent = `£${subtotal.toFixed(2)}`;
    deliveryFeeText.textContent = deliveryFee === 0 ? "FREE" : `£${deliveryFee.toFixed(2)}`;
    grandTotalText.textContent = `£${grandTotal.toFixed(2)}`;

    // Pre-fill user delivery address if empty
    if (!addressInput.value && currentUser && currentUser.customerId) {
        apiFetch(`/customers/${currentUser.customerId}`)
            .then(cust => {
                if (cust && cust.address) addressInput.value = cust.address;
            })
            .catch(() => {});
    }

    if (cart.length === 0) {
        container.innerHTML = `
            <div style="text-align: center; padding: 48px 20px;">
                <span style="font-size: 52px; display: block; margin-bottom: 12px;">🛒</span>
                <h3 style="color: white; margin-bottom: 6px;">Your cart is empty</h3>
                <p class="text-dim" style="margin-bottom: 16px;">Add delicious dishes from the menu to start your order!</p>
                <button type="button" class="btn-primary" onclick="showSection('browseFood')">
                    Browse Food Menu
                </button>
            </div>
        `;
        document.getElementById("placeOrderBtn").disabled = true;
        return;
    }

    document.getElementById("placeOrderBtn").disabled = false;
    container.innerHTML = "";

    cart.forEach(item => {
        const itemSubtotal = (Number(item.foodItem.price) * item.quantity).toFixed(2);
        const emoji = getFoodEmoji(item.foodItem.name);
        const restName = item.foodItem.restaurant ? item.foodItem.restaurant.name : "Restaurant";

        const row = document.createElement("div");
        row.className = "cart-item-row";
        row.innerHTML = `
            <div class="cart-item-info">
                <span class="cart-item-emoji">${emoji}</span>
                <div>
                    <div class="cart-item-name">${item.foodItem.name}</div>
                    <div class="cart-item-rest">🏪 ${restName}</div>
                </div>
            </div>
            <div class="cart-item-right">
                <div class="cart-qty-ctrl">
                    <button type="button" class="qty-btn" onclick="updateCartQty(${item.foodItem.id}, -1)">−</button>
                    <span class="qty-num">${item.quantity}</span>
                    <button type="button" class="qty-btn" onclick="updateCartQty(${item.foodItem.id}, 1)">+</button>
                </div>
                <div class="cart-item-price">£${itemSubtotal}</div>
                <button type="button" class="cart-item-delete" onclick="removeFromCart(${item.foodItem.id})" title="Remove item">🗑️</button>
            </div>
        `;
        container.appendChild(row);
    });
}

async function handlePlaceOrder() {
    if (cart.length === 0) {
        showToast("Your cart is empty!", "error");
        return;
    }

    const deliveryAddress = document.getElementById("checkoutAddress").value.trim();
    if (!deliveryAddress) {
        showToast("Please enter your delivery destination address.", "error");
        document.getElementById("checkoutAddress").focus();
        return;
    }

    const btn = document.getElementById("placeOrderBtn");
    const originalText = btn.innerHTML;
    btn.innerHTML = `<span>Placing Order...</span>`;
    btn.disabled = true;

    try {
        // Group items by Restaurant
        const itemsByRestaurant = {};
        cart.forEach(c => {
            const restId = c.foodItem.restaurant?.id || 1;
            if (!itemsByRestaurant[restId]) {
                itemsByRestaurant[restId] = [];
            }
            itemsByRestaurant[restId].push({
                foodItemId: c.foodItem.id,
                quantity: c.quantity
            });
        });

        const restIds = Object.keys(itemsByRestaurant);

        // Place an order for each restaurant cart
        for (const rId of restIds) {
            const orderPayload = {
                customerId: currentUser.customerId,
                restaurantId: Number(rId),
                deliveryAddress: deliveryAddress,
                items: itemsByRestaurant[rId]
            };

            await apiFetch("/orders", {
                method: "POST",
                body: JSON.stringify(orderPayload)
            });
        }

        // Success!
        clearCart();
        showToast("🎉 Order placed successfully! Tracking your delivery now.", "success");
        showSection("myOrders");
    } catch (err) {
        console.error("Place order error:", err);
        showToast(err.message || "Failed to place order. Please try again.", "error");
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
}

/* ==========================================================================
   CUSTOMER: MY ORDERS & LIVE TRACKING
   ========================================================================== */

async function loadMyOrders() {
    const container = document.getElementById("myOrdersList");
    container.innerHTML = `<div style="text-align: center; padding: 40px;"><p class="text-dim">Loading your orders...</p></div>`;

    try {
        const orders = await apiFetch("/orders/my");

        if (orders.length === 0) {
            container.innerHTML = `
                <div style="text-align: center; padding: 60px 20px; background: var(--bg-card); border-radius: var(--radius-lg); border: 1px solid var(--border);">
                    <span style="font-size: 52px; display: block; margin-bottom: 12px;">📦</span>
                    <h3 style="color: white; margin-bottom: 6px;">No orders placed yet</h3>
                    <p class="text-dim" style="margin-bottom: 16px;">Browse the food catalog and treat yourself today!</p>
                    <button type="button" class="btn-primary" onclick="showSection('browseFood')">
                        Order Food Now
                    </button>
                </div>
            `;
            return;
        }

        container.innerHTML = "";

        // Sort descending by order date or id
        orders.sort((a, b) => b.id - a.id);

        orders.forEach(order => {
            const card = document.createElement("div");
            card.className = "order-tracker-card";

            const restName = order.restaurant ? order.restaurant.name : "Restaurant";
            const dateStr = order.orderDate ? new Date(order.orderDate).toLocaleString() : "";
            const total = Number(order.totalAmount || 0).toFixed(2);
            const status = order.status || "PLACED";

            // Status stage mapping
            const stages = ["PLACED", "PREPARING", "OUT_FOR_DELIVERY", "DELIVERED"];
            const currentStageIndex = stages.indexOf(status);

            const stepperHtml = status === "CANCELLED" 
                ? `<div style="text-align: center; padding: 12px; background: var(--rose-light); color: #fb7185; border-radius: var(--radius-sm); font-weight: 700;">Order Cancelled</div>`
                : `
                    <div class="timeline-stepper">
                        <div class="timeline-step ${currentStageIndex >= 0 ? (currentStageIndex > 0 ? 'completed' : 'active') : ''}">
                            <div class="step-node">${currentStageIndex > 0 ? '✓' : '1'}</div>
                            <div class="step-label">Order Placed</div>
                        </div>
                        <div class="timeline-step ${currentStageIndex >= 1 ? (currentStageIndex > 1 ? 'completed' : 'active') : ''}">
                            <div class="step-node">${currentStageIndex > 1 ? '✓' : '2'}</div>
                            <div class="step-label">In Kitchen</div>
                        </div>
                        <div class="timeline-step ${currentStageIndex >= 2 ? (currentStageIndex > 2 ? 'completed' : 'active') : ''}">
                            <div class="step-node">${currentStageIndex > 2 ? '✓' : '3'}</div>
                            <div class="step-label">Out for Delivery</div>
                        </div>
                        <div class="timeline-step ${currentStageIndex >= 3 ? 'completed' : ''}">
                            <div class="step-node">${currentStageIndex >= 3 ? '✓' : '4'}</div>
                            <div class="step-label">Delivered</div>
                        </div>
                    </div>
                `;

            const itemsListHtml = (order.items || []).map(i => `
                <div class="drawer-item">
                    <span>${i.quantity}x ${i.foodItem?.name || 'Item'}</span>
                    <strong>£${(Number(i.price) * Number(i.quantity)).toFixed(2)}</strong>
                </div>
            `).join("");

            card.innerHTML = `
                <div class="order-tracker-header">
                    <div>
                        <span class="order-number">Order #${order.id}</span>
                        <span class="order-date-pill">${dateStr}</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 12px;">
                        <span class="status-pill status-${status.toLowerCase()}">${status}</span>
                        <strong class="text-amber" style="font-size: 18px;">£${total}</strong>
                    </div>
                </div>

                ${stepperHtml}

                <div class="order-details-drawer">
                    <div style="display: flex; justify-content: space-between; font-size: 13px; color: var(--text-dim);">
                        <span>Restaurant: <strong>${restName}</strong></span>
                        <span>Destination: <strong>${order.deliveryAddress}</strong></span>
                    </div>
                    <div class="drawer-items-list">
                        ${itemsListHtml}
                    </div>
                </div>
            `;

            container.appendChild(card);
        });
    } catch (err) {
        console.error("My orders error:", err);
    }
}

/* ==========================================================================
   CUSTOMER: PROFILE & STATS
   ========================================================================== */

async function loadCustomerProfile() {
    try {
        const stats = await apiFetch("/dashboard/customer");
        document.getElementById("custStatTotalOrders").textContent = stats.totalOrders || 0;
        document.getElementById("custStatActiveOrders").textContent = stats.activeOrders || 0;
        document.getElementById("custStatDeliveredOrders").textContent = stats.deliveredOrders || 0;
        document.getElementById("custStatTotalSpent").textContent = `£${Number(stats.totalSpent || 0).toFixed(2)}`;

        // Load profile details
        if (currentUser && currentUser.customerId) {
            const customer = await apiFetch(`/customers/${currentUser.customerId}`);
            document.getElementById("profileNameDisplay").textContent = customer.name;
            document.getElementById("profileAvatarLarge").textContent = customer.name.charAt(0).toUpperCase();
            document.getElementById("profileUsernameDisplay").textContent = currentUser.username;
            document.getElementById("profileEmailDisplay").textContent = customer.email;
            document.getElementById("profilePhoneDisplay").textContent = customer.phone;
            document.getElementById("profileAddressDisplay").textContent = customer.address;
        }
    } catch (err) {
        console.error("Profile load error:", err);
    }
}

/* ==========================================================================
   MODAL UTILITIES
   ========================================================================== */

function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove("hidden");
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add("hidden");
    }
}

function handleBackdropClick(e, modalId) {
    if (e.target.id === modalId) {
        closeModal(modalId);
    }
}

function populateRestaurantSelects() {
    apiFetch("/restaurants")
        .then(restaurants => {
            allRestaurants = restaurants;
            
            const foodRestSelect = document.getElementById("newFoodRestaurantId");
            const foodFilterSelect = document.getElementById("foodRestaurantFilter");

            if (foodRestSelect) {
                foodRestSelect.innerHTML = `<option value="">Select Restaurant...</option>`;
                restaurants.forEach(r => {
                    foodRestSelect.innerHTML += `<option value="${r.id}">${r.name} (${r.cuisineType})</option>`;
                });
            }

            if (foodFilterSelect) {
                foodFilterSelect.innerHTML = `<option value="">All Restaurants</option>`;
                restaurants.forEach(r => {
                    foodFilterSelect.innerHTML += `<option value="${r.id}">${r.name}</option>`;
                });
            }
        })
        .catch(() => {});
}

/* ==========================================================================
   TOAST SYSTEM
   ========================================================================== */

function showToast(message, type = "info") {
    const container = document.getElementById("toastContainer");
    if (!container) return;

    const icons = {
        success: "✓",
        error: "✕",
        info: "ℹ"
    };

    const toast = document.createElement("div");
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <span class="toast-icon">${icons[type] || 'ℹ'}</span>
        <span class="toast-text">${message}</span>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = "0";
        toast.style.transform = "translateX(50px)";
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}